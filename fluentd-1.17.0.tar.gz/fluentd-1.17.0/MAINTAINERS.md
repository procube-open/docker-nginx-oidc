# Fluentd Maintainers

- [Naotoshi Seo](https://github.com/sonots), [ZOZO Technologies](https://tech.zozo.com/en/)
- [Okkez](https://github.com/okkez)
- [Hiroshi Hatake](https://github.com/cosmo0920), [Calyptia](https://calyptia.com/)
- [Masahiro Nakagawa](https://github.com/repeatedly)
- [Satoshi Tagomori](https://github.com/tagomoris)
- [Toru Takahashi](https://github.com/toru-takahashi), [Treasure Data](https://www.treasuredata.com/)
- [Eduardo Silva](https://github.com/edsiper), [Calyptia](https://calyptia/)
- [Fujimoto Seiji](https://github.com/fujimots)
- [Takuro Ashie](https://github.com/ashie), [ClearCode](https://www.clear-code.com/)
- [Kentaro Hayashi](https://github.com/kenhys), [ClearCode](https://www.clear-code.com/)
- [Daijiro Fukuda](https://github.com/daipom), [ClearCode](https://www.clear-code.com/)

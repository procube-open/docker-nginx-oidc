# Fluentd Adopters

Fluentd is widely used by hundred of companies, please refer to the testimonial section of our project website  to learn more about it:

https://www.fluentd.org/testimonials
